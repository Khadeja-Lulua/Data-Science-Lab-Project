install.packages('ggplot2',dependencies = TRUE)
install.packages('caTools',dependencies = TRUE)
library(readr)
library(ggplot2)
library(caTools)
# Reading the Dataset #
dengue_project <- read_csv("dengue_project.csv")
# Summary of the dataset
summary(dengue_project)
View(head(dengue_project))


# Plotting Histograms of the numerical Columns
x<-colnames(dengue_project)
for (i in c(5:24))
{
  hist(as.numeric(unlist(dengue_project[,i])), xlab = x[i], main = "Histogram")
}


# Missing Value treatment based on the histogram distributions

for (i in c(6:25))
{
  dengue_project[is.na(dengue_project[,i]),i]<-na.rm(dengue_project[,i])
}

# Coverting Categorical variables
dengue_project$city<-as.factor(dengue_project$city)

# EDA

## Box plots for city wise cases
ggplot(dengue_project, aes(y = total_cases, x = city, color = total_cases)) +geom_boxplot() +coord_flip()

## Scatter plots with dependent variables
for (i in c(6:25))
{
  print(ggplot(dengue_project, aes(y = total_cases, 
                                   x = as.numeric(unlist(dengue_project[,i])))) +
          geom_point()+labs(y="total cases", x = x[i]))
}

# Splitting data into test and train
set.seed(101) 
sample <- sample.split(dengue_project$total_cases, SplitRatio = .75)
train <- subset(dengue_project, sample == TRUE)
test  <- subset(dengue_project, sample == FALSE)
train<-train[,-c(5)]
## Linear Model
model<-glm(total_cases~.-reanalysis_sat_precip_amt_mm
           -ndvi_se
           -reanalysis_air_temp_k,family = 'poisson', data = train)
summary(model)
# Calculating Mean Absolute Error
test<-test[,-c(5)]
test$predict<-predict(model,test)
MAE<-mean(abs(test$total_cases-test$predict))
MAE

save.image(file = "project.RData")

